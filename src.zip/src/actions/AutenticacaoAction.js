import firebase from 'firebase'
import { Actions } from 'react-native-router-flux'
import b64 from 'base-64'
import * as typeAction from '../actions/ActionTypes'

export const modificaEmail = text => {
  return {
    type: typeAction.MODIFICA_EMAIL,
    payload: text
  }
}
export const modificaSenha = text => {
  return {
    type: typeAction.MODIFICA_SENHA,
    payload: text
  }
}

export const modificaNome = text => {
  return {
    type: typeAction.MODIFICA_NOME,
    payload: text
  }
}

export const cadastraUsuario = ({nome, email, senha}) => {
  return dispatch => {
    firebase.auth().createUserWithEmailAndPassword(email, senha)
      .then(user => {
        let emailB64 = b64.encode(email)
        firebase.database().ref(`/contatos/${emailB64}`)
          .push({nome})
          .then(value => cadastroSucess(dispatch))
      })
      .catch(erro => cadastroFail(erro, dispatch))
  }

}

const cadastroSucess = (dispatch) => {
  dispatch({type: typeAction.SIGNUP_SUCESS})
  Actions.boasVindas()
}

const cadastroFail = (erro, dispatch) => {
  dispatch({
    type: typeAction.SIGNUP_ERROR,
    payload: erro.message
  })
}

export const autenticaUsuario = ({email, senha}) => {
  return dispatch => {
    firebase.auth().signInWithEmailAndPassword(email, senha)
      .then(value => loginUserSucess(dispatch))
      .catch(erro => loginUserErro(erro, dispatch))
  }
}

const loginUserSucess = (dispatch) => {
  dispatch({
    type: typeAction.SIGNIN_SUCESS
  })
  Actions.principal()
}

const loginUserErro = (erro, dispatch) => {
  dispatch({
    type: typeAction.SIGNIN_ERROR,
    payload: erro.message
  })
}