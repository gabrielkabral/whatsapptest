export const MODIFICA_EMAIL = 'modifica_email'
export const MODIFICA_SENHA = 'modifica_senha'
export const MODIFICA_NOME = 'modifica_nome'
export const SIGNUP_SUCESS = 'signup_sucess'
export const SIGNUP_ERROR = 'signup_error'
export const SIGNIN_SUCESS = 'signin_sucess'
export const SIGNIN_ERROR = 'signin_error'

