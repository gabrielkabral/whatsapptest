import * as typeAction from '../actions/ActionTypes'

const INITIAL_STATE = {
  nome: '',
  email: '',
  senha: '',
  erroCadastro: '',
  erroLogin: ''
}

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case typeAction.SIGNIN_ERROR:
      return {...state, erroLogin: action.payload}
    case typeAction.SIGNIN_SUCESS:
      return {...state, nome:''}
    case typeAction.SIGNUP_SUCESS:
      return {...state, nome: '', senha: ''}
    case typeAction.SIGNUP_ERROR:
      return {...state, erroCadastro: action.payload}
    case typeAction.MODIFICA_EMAIL:
      return {...state, email: action.payload}
    case typeAction.MODIFICA_SENHA:
      return {...state, senha: action.payload}
    case typeAction.MODIFICA_NOME:
      return {...state, nome: action.payload}
  }
  return state
}

