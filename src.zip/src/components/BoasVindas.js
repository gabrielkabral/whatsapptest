import React from 'react'
import { View, Text, Button, Image, StyleSheet, ImageBackground} from 'react-native'
import { Actions } from 'react-native-router-flux'

const logo = require('../../imgs/logo.png')
const background = require('../../imgs/bg.png')

export default props => (
  <ImageBackground style={{flex:1}} source={background}>
    <View style={styles.mainView}>
      <View style={styles.topView}>
        <Text style={styles.welcomeText}> Seja Bem-Vindo </Text>
        <Image source={logo} />
      </View>
      <View style={styles.bottomView}>
        <View style={styles.buttonView}>
          <Button color='white' title='Fazer Login' onPress={ Actions.formLogin }/>
        </View>
      </View>
    </View>
  </ImageBackground>
)


const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    padding: 15
  },
  topView: {
    flex: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  welcomeText: {
    fontSize: 30,
    color: 'white',
    paddingBottom: 20
  },
  bottomView: {
    flex: 1,
    alignItems: 'center'
  },
  buttonView: {
    width: 300,
    backgroundColor: '#115E45'
  },

})