import React, { Component } from 'react'
import { Text } from 'react-native'

export default class Principal extends Component{
  render() {
    return(
      <Text style={{flex:1, alignItems: 'center', justifyContent: 'center', fontSize: 50}}>asdasdas</Text>
    )
  }
}