import React, { Component } from 'react'
import { View, TextInput, Button, StyleSheet, ImageBackground, Text } from 'react-native'
import { connect } from 'react-redux'
import { modificaEmail, modificaSenha, modificaNome, cadastraUsuario } from '../actions/AutenticacaoAction'

const background = require('../../imgs/bg.png')

class FormCadastro extends Component {
  _cadastraUsuario () {
    const {nome, email, senha} = this.props
    this.props.cadastraUsuario({nome, email, senha})
  }
  render () {
    return (
      <ImageBackground style={{flex: 1}} source={background}>
        <View style={styles.mainView}>
          <View style={styles.firstInside}>
            <View style={styles.paddingInput}>
              <TextInput value={this.props.nome} placeholderTextColor='white' placeholder="Nome" style={styles.inputText}
                         onChangeText={texto => this.props.modificaNome(texto)}/>
            </View>
            <View style={styles.paddingInput}>
              <TextInput value={this.props.email} placeholderTextColor='white' placeholder="E-mail" style={styles.inputText}
                         onChangeText={texto => this.props.modificaEmail(texto)}/>
            </View>
            <View style={styles.paddingInput}>
              <TextInput secureTextEntry={true} value={this.props.senha} placeholderTextColor='white' placeholder="Senha" style={styles.inputText}
                         onChangeText={texto => this.props.modificaSenha(texto)}/>
            </View>
            <Text style={styles.textError}>
              {this.props.erroCadastro}
            </Text>
          </View>
          <View style={styles.secondInside}>
            <View style={styles.buttonView}>
              <Button color='white' title='Cadastrar' onPress={() => { this._cadastraUsuario() }}/>
            </View>
          </View>
        </View>
      </ImageBackground>
    )
  }
}

const mapStateToProps = state => ({
  nome: state.AutenticacaoReducer.nome,
  email: state.AutenticacaoReducer.email,
  senha: state.AutenticacaoReducer.senha,
  erroCadastro: state.AutenticacaoReducer.erroCadastro
})

export default connect(mapStateToProps, {modificaEmail, modificaSenha, modificaNome, cadastraUsuario})(FormCadastro)

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    padding: 10,
    alignItems: 'center',
  },
  firstInside: {
    flex: 4,
    justifyContent: 'center'
  },
  inputText: {
    fontSize: 20,
    height: 45,
    color: 'white',
    borderWidth: 1,
    width: 300,
    textAlign: 'center',
    borderRadius: 8,
  },
  secondInside: {
    flex: 1
  },
  buttonView: {
    width: 300,
    backgroundColor: '#115E45'
  },
  paddingInput: {
    padding: 10
  },
  textError: {
    color:'red',
    fontSize: 20,
  }
})