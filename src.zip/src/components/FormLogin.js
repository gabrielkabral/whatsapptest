import React, { Component }from 'react'
import { View, Text, StyleSheet, TextInput, Button, TouchableHighlight, ImageBackground } from 'react-native'
import { Actions } from 'react-native-router-flux'
import { connect } from 'react-redux'
import { modificaEmail, modificaSenha, autenticaUsuario } from '../actions/AutenticacaoAction'

const background = require('../../imgs/bg.png')

class FormLogin extends Component {

  _autenticaUsuario (){
    const {email, senha} = this.props
    this.props.autenticaUsuario({email, senha})
  }


  render() {
    return (
      <ImageBackground style={{flex: 1}} source={background}>
        <View style={styles.mainTela}>
          <View style={styles.divTop}>
            <Text style={styles.topo}>Whatsapp Clone</Text>
          </View>
          <View style={styles.divMid}>
            <View style={styles.paddingInput}>
              <TextInput value={this.props.email} placeholderTextColor='white' placeholder='Email' style={styles.inputText}
                         onChangeText={texto => this.props.modificaEmail(texto)}/>
            </View>
            <View style={styles.paddingInput}>
              <TextInput secureTextEntry={true} value={this.props.senha} placeholderTextColor='white' placeholder='Nome'
                         style={styles.inputText}
                         onChangeText={texto => this.props.modificaSenha(texto)}/>
              <Text style={styles.textError}>{this.props.erroLogin}</Text>
            </View>
            <TouchableHighlight style={styles.touchCadastro} onPress={Actions.formCadastro}>
              <Text style={styles.textCadastro}>Ainda não tem cadastro? Cadastre-se</Text>
            </TouchableHighlight>
          </View>
          <View style={styles.divBot}>
            <View style={{width: 300, backgroundColor: '#115E45'}}>
              <Button color='white' title='Acessar' onPress={() => {this._autenticaUsuario()}}/>
            </View>
          </View>
        </View>
      </ImageBackground>
    )
  }
}

const mapStateToProps = state => ({
  email: state.AutenticacaoReducer.email,
  senha: state.AutenticacaoReducer.senha,
  erroLogin: state.AutenticacaoReducer.erroLogin,
})

export default connect(mapStateToProps, {modificaEmail, modificaSenha, autenticaUsuario})(FormLogin)

const styles = StyleSheet.create({
  mainTela: {
    flex: 1,
  },
  divTop: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  topo: {
    fontSize: 35,
    backgroundColor: 'transparent',
    color: 'white'
  },
  touchCadastro: {
    paddingTop: 10
  },
  divMid: {
    flex: 2,
    justifyContent: 'center',
    alignItems: 'center'
  },
  divBot: {
    flex: 2,
    justifyContent: 'center',
    alignItems: 'center'
  },
  inputText: {
    fontSize: 20,
    height: 45,
    color: 'white',
    borderWidth: 1,
    width: 300,
    textAlign: 'center',
    borderRadius: 8,
    flexDirection: 'row',
  },
  textCadastro: {
    color: 'white',
    fontSize: 20,
    paddingTop: 30
  },
  paddingInput: {
    padding: 10
  },
  textError: {
    color:'red',
    fontSize: 20,
  }
})
